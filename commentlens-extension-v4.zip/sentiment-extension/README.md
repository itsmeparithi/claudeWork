# CommentLens – Sentiment Tabs

**Categorizes YouTube & Twitter/X comments into sentiment-based tabs — entirely in your browser. No data ever leaves your device.**

---

## 📦 Installation (Developer Mode)

1. **Download / unzip** the `commentlens-extension` folder somewhere on your computer.

2. Open **Chrome** and navigate to:
   ```
   chrome://extensions
   ```

3. Enable **Developer mode** (toggle in the top-right corner).

4. Click **"Load unpacked"** and select the `commentlens-extension` folder.

5. The CommentLens icon (💬) will appear in your Chrome toolbar.

---

## 🚀 How to Use

### YouTube
1. Go to any YouTube video: `https://www.youtube.com/watch?v=...`
2. Scroll down to the comments section.
3. Wait ~2–3 seconds for comments to load.
4. **CommentLens automatically appears above the comments** with 5 sentiment tabs.

### Twitter / X
1. Click on any tweet to open its detail page (replies view).
2. Wait ~2 seconds for replies to load.
3. **CommentLens appears above the replies** with 5 sentiment tabs.

---

## 🗂️ Categories

| Tab | Emoji | What it contains |
|-----|-------|-----------------|
| **Supportive** | 💚 | Praise, agreement, encouragement, love |
| **Critical** | 🔴 | Disagreement, opposition, counterpoints |
| **Neutral** | ⚪ | Questions, observations, general chat |
| **Toxic** | 🚫 | Rude, vulgar or derogatory comments |
| **Other** | 📦 | Spam, very short or unclassifiable |

> **Supportive** is always the default tab.

---

## 🏗️ Architecture

```
commentlens-extension/
├── manifest.json          # Chrome Extension Manifest V3
├── popup.html             # Toolbar popup UI
├── icons/                 # Extension icons (16, 48, 128px)
└── src/
    ├── sentiment.js       # In-browser sentiment engine (lexicon + rules)
    ├── overlay.js         # Shared tabbed UI injector
    ├── overlay.css        # Dark-mode overlay styles
    ├── youtube.js         # YouTube comment scraper + mount logic
    └── twitter.js         # Twitter/X reply scraper + mount logic
```

### Sentiment Engine

The analysis runs **100% client-side** using a weighted lexicon approach:

- **~100 supportive words** (love, amazing, agree, thanks, brilliant…)
- **~60 critical words** (wrong, disagree, false, fail, boring…)
- **Toxic regex patterns** (profanity, hate speech, slurs, threats)
- **Negation handling** — "not great" → critical, "not bad" → supportive
- **Intensifier boosting** — "absolutely amazing" scores higher than "amazing"
- No ML model, no API, no network requests.

---

## 🔒 Privacy

- ✅ Zero network requests for analysis
- ✅ No comment data stored or transmitted
- ✅ No user tracking
- ✅ Permissions: `activeTab` and `storage` only

---

## 🛣️ Roadmap

- [ ] Reddit support
- [ ] Instagram support
- [ ] Adjustable sensitivity slider
- [ ] Export categorized comments as CSV
- [ ] Highlight mode (color-code comments in-place)
- [ ] Stats dashboard per video/post

---

## 🐛 Troubleshooting

**Comments not detected?**
- Scroll down to load comments first, then wait 2–3 seconds
- YouTube lazy-loads comments — keep scrolling if needed
- Refresh the page if the overlay doesn't appear

**Twitter/X not working?**
- Make sure you're on a tweet detail page (clicked through to a specific tweet)
- The extension only runs on reply pages, not the main timeline

**Wrong category for a comment?**
- The lexicon-based engine isn't perfect — irony and sarcasm can fool it
- This is a known limitation of rule-based analysis; a future ML version will handle these better
