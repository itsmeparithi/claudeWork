/**
 * CommentLens – Twitter/X Content Script
 * Scrapes replies on tweet detail pages and injects the sentiment overlay.
 */

(function () {
  "use strict";

  const PLATFORM = "twitter";
  let observer = null;
  let debounceTimer = null;
  let lastUrl = location.href;
  let isProcessing = false;

  // ─── SELECTORS ───────────────────────────────────────────────────────────────
  // Twitter/X uses data-testid attributes which are more stable than class names

  const SELECTORS = {
    // The primary tweet being viewed
    primaryTweet: '[data-testid="primaryColumn"]',
    // Each reply / tweet cell in the timeline
    tweetCell: '[data-testid="cellInnerDiv"]',
    // Text content of a tweet
    tweetText: '[data-testid="tweetText"]',
    // User name (display name)
    userName: '[data-testid="User-Name"]',
    // Avatar image
    avatar: '[data-testid="Tweet-User-Avatar"] img',
  };

  // ─── SCRAPER ─────────────────────────────────────────────────────────────────

  function isTweetDetailPage() {
    return /\/(status|statuses)\/\d+/.test(location.pathname);
  }

  function scrapeReplies() {
    const cells = document.querySelectorAll(SELECTORS.tweetCell);
    const comments = [];
    let skippedFirst = false; // Skip the original tweet itself

    cells.forEach((cell, idx) => {
      const textEl = cell.querySelector(SELECTORS.tweetText);
      if (!textEl) return;

      const text = textEl.innerText?.trim();
      if (!text || text.length < 2) return;

      // Skip the very first tweet (the one being replied to)
      if (!skippedFirst) {
        skippedFirst = true;
        return;
      }

      // Author display name
      const userNameEl = cell.querySelector(SELECTORS.userName);
      let authorName = "Anonymous";
      if (userNameEl) {
        // First span is display name, second is @handle
        const spans = userNameEl.querySelectorAll("span");
        authorName = spans[0]?.innerText?.trim() || "Anonymous";
      }

      // Avatar
      const avatarEl = cell.querySelector(SELECTORS.avatar);
      const avatarUrl = avatarEl?.src || null;

      comments.push({
        id: idx,
        text,
        authorName,
        avatarUrl,
        el: cell
      });
    });

    return comments;
  }

  // ─── MOUNT ───────────────────────────────────────────────────────────────────

  function tryMount() {
    if (isProcessing) return;
    if (!isTweetDetailPage()) return;

    const primaryCol = document.querySelector(SELECTORS.primaryTweet);
    if (!primaryCol) return;

    const cells = document.querySelectorAll(SELECTORS.tweetCell);
    // Need at least 2 cells (original tweet + at least 1 reply)
    if (cells.length < 2) return;

    isProcessing = true;

    const comments = scrapeReplies();
    if (comments.length === 0) {
      isProcessing = false;
      return;
    }

    // Mount point: just after the primary tweet section
    let mountPoint = document.querySelector(".cl-mount-tw");
    if (!mountPoint) {
      mountPoint = document.createElement("div");
      mountPoint.className = "cl-mount-tw";
      // Insert after the first cell (original tweet)
      const firstCell = document.querySelector(SELECTORS.tweetCell);
      if (firstCell?.parentNode) {
        firstCell.parentNode.insertBefore(mountPoint, firstCell.nextSibling);
      } else {
        primaryCol.prepend(mountPoint);
      }
    }

    window.CommentLensUI.render(mountPoint, comments, { platform: PLATFORM });
    isProcessing = false;
  }

  function debouncedMount(delay = 1500) {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(tryMount, delay);
  }

  // ─── OBSERVE ─────────────────────────────────────────────────────────────────

  function startObserving() {
    if (observer) observer.disconnect();

    observer = new MutationObserver(() => {
      if (isTweetDetailPage()) {
        debouncedMount(800);
      }
    });

    observer.observe(document.body, { childList: true, subtree: true });
  }

  // ─── SPA NAV ─────────────────────────────────────────────────────────────────

  function onNavChange() {
    const currentUrl = location.href;
    if (currentUrl === lastUrl) return;
    lastUrl = currentUrl;

    const existing = document.getElementById("commentlens-overlay");
    if (existing) existing.remove();

    const mountPoint = document.querySelector(".cl-mount-tw");
    if (mountPoint) mountPoint.remove();

    isProcessing = false;

    if (isTweetDetailPage()) {
      debouncedMount(2000);
    }
  }

  const _pushState = history.pushState.bind(history);
  history.pushState = function (...args) {
    _pushState(...args);
    onNavChange();
  };

  window.addEventListener("popstate", onNavChange);

  // ─── INIT ────────────────────────────────────────────────────────────────────

  function init() {
    startObserving();
    if (isTweetDetailPage()) {
      debouncedMount(2500);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

})();
