/**
 * CommentLens – Overlay UI v4
 * Reclassification is open to all users — corrections are local-only (chrome.storage.local)
 * and never affect anyone else's browser.
 */

(function () {
  "use strict";

  window.CommentLensUI = {

    async render(mountPoint, comments, options = {}) {
      const { CATEGORIES, classify, classifySync, PERSPECTIVE_KEY } = window.CommentLens;
      const FB = window.CommentLensFeedback;

      // Refresh learned weights before classifying
      if (FB) await FB.refreshLearnedCache();

      // Phase 1: instant sync render — apply any existing user corrections first
      const classified = await Promise.all(comments.map(async c => {
        const correction = FB ? await FB.getCorrection(c.text) : null;
        return {
          ...c,
          category:  correction ? correction.correct : classifySync(c.text),
          corrected: !!correction,
        };
      }));

      _buildOverlay(mountPoint, classified, CATEGORIES, options, false);

      // Phase 2: async Perspective API upgrade (only if key is configured)
      if (!PERSPECTIVE_KEY) return;

      const asyncClassified = await Promise.all(
        classified.map(async c => {
          if (c.corrected) return c; // User corrections always win
          return { ...c, category: await classify(c.text) };
        })
      );

      if (asyncClassified.some((ac, i) => ac.category !== classified[i].category)) {
        _buildOverlay(mountPoint, asyncClassified, CATEGORIES, options, true);
      }
    }
  };

  // ─── BUILD OVERLAY ───────────────────────────────────────────────────────────

  function _buildOverlay(mountPoint, classified, CATEGORIES, options, isAsync) {
    const counts = {};
    Object.keys(CATEGORIES).forEach(k => (counts[k] = 0));
    classified.forEach(c => counts[c.category]++);

    const existing = document.getElementById("commentlens-overlay");
    let rememberedTab = "supportive";
    if (existing) {
      const activeEl = existing.querySelector(".cl-tab--active");
      if (activeEl) rememberedTab = activeEl.dataset.cat;
      existing.remove();
    }

    const overlay   = document.createElement("div");
    overlay.id      = "commentlens-overlay";
    overlay.setAttribute("data-platform", options.platform || "unknown");

    const tabOrder  = ["supportive", "critical", "neutral", "toxic", "other"];
    let activeTab   = rememberedTab;

    // ── Header ──
    const header    = document.createElement("div");
    header.className = "cl-header";
    header.innerHTML = `
      <span class="cl-logo">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
        </svg>
        CommentLens
      </span>
      <span class="cl-header-right">
        <span class="cl-badge ${isAsync ? "cl-badge--api" : "cl-badge--local"}">
          ${isAsync ? "🌐 AI" : "⚡ Local"}
        </span>
        <span class="cl-total">${classified.length} comments</span>
      </span>
    `;

    // ── Distribution bar ──
    const chart = document.createElement("div");
    chart.className = "cl-chart";
    const total = classified.length || 1;
    tabOrder.forEach(catId => {
      const pct = (counts[catId] / total) * 100;
      if (pct < 0.5) return;
      const seg = document.createElement("div");
      seg.className = "cl-chart-seg";
      seg.style.width = pct.toFixed(1) + "%";
      seg.style.background = CATEGORIES[catId].color;
      seg.title = `${CATEGORIES[catId].shortLabel}: ${counts[catId]} (${Math.round(pct)}%)`;
      chart.appendChild(seg);
    });

    // ── Tab bar + panels ──
    const tabBar   = document.createElement("div");
    tabBar.className = "cl-tabbar";
    const panelsEl = document.createElement("div");
    panelsEl.className = "cl-panels";

    tabOrder.forEach(catId => {
      const cat        = CATEGORIES[catId];
      const catComments = classified.filter(c => c.category === catId);
      const isActive   = catId === activeTab;

      // Tab button
      const tab = document.createElement("button");
      tab.className = "cl-tab" + (isActive ? " cl-tab--active" : "");
      tab.dataset.cat = catId;
      tab.style.setProperty("--cat-color", cat.color);
      tab.innerHTML = `
        <span class="cl-tab-emoji">${cat.emoji}</span>
        <span class="cl-tab-label">${cat.shortLabel}</span>
        <span class="cl-tab-count">${catComments.length}</span>
      `;
      tab.addEventListener("click", () => switchTab(catId));
      tabBar.appendChild(tab);

      // Panel
      const panel = document.createElement("div");
      panel.className = "cl-panel" + (isActive ? " cl-panel--active" : "");
      panel.dataset.cat = catId;

      if (catComments.length === 0) {
        panel.innerHTML = `
          <div class="cl-empty">
            <span class="cl-empty-emoji">${cat.emoji}</span>
            <p>No ${cat.shortLabel.toLowerCase()} comments found</p>
          </div>
        `;
      } else {
        const list = document.createElement("div");
        list.className = "cl-list";
        catComments.forEach(c => list.appendChild(_buildCard(c, catId, cat, CATEGORIES)));
        panel.appendChild(list);
      }

      panelsEl.appendChild(panel);
    });

    function switchTab(catId) {
      activeTab = catId;
      tabBar.querySelectorAll(".cl-tab").forEach(t =>
        t.classList.toggle("cl-tab--active", t.dataset.cat === catId));
      panelsEl.querySelectorAll(".cl-panel").forEach(p =>
        p.classList.toggle("cl-panel--active", p.dataset.cat === catId));
    }

    overlay.appendChild(header);
    overlay.appendChild(chart);
    overlay.appendChild(tabBar);
    overlay.appendChild(panelsEl);
    mountPoint.prepend(overlay);
  }

  // ─── BUILD COMMENT CARD ───────────────────────────────────────────────────────

  function _buildCard(c, catId, cat, CATEGORIES) {
    const card = document.createElement("div");
    card.className = "cl-card" + (c.corrected ? " cl-card--corrected" : "");
    card.style.setProperty("--cat-color", cat.color);

    const initials = (c.authorName || "?")
      .replace(/[^a-zA-Z\u00C0-\u024F\u0400-\u04FF\u0B80-\u0D7F\u4e00-\u9fff]/g, "")[0]
      ?.toUpperCase() || "?";

    const avatar = c.avatarUrl
      ? `<img class="cl-avatar" src="${c.avatarUrl}" alt="" loading="lazy" onerror="this.style.display='none'">`
      : `<div class="cl-avatar cl-avatar--fallback">${initials}</div>`;

    const isToxic = catId === "toxic";
    const correctedBadge = c.corrected
      ? `<span class="cl-corrected-badge" title="You reclassified this">✓ Reclassified</span>`
      : "";

    card.innerHTML = `
      <div class="cl-card-meta">
        ${avatar}
        <span class="cl-author">${escapeHtml(c.authorName || "Anonymous")}</span>
        <span class="cl-spacer"></span>
        ${correctedBadge}
        <span class="cl-cat-pill" style="--cat-color:${cat.color}">${cat.emoji} ${cat.shortLabel}</span>
      </div>
      ${isToxic
        ? `<p class="cl-text cl-text--blurred" title="Click to reveal">${escapeHtml(c.text)}</p>
           <button class="cl-reveal">🔓 Click to reveal</button>`
        : `<p class="cl-text">${escapeHtml(c.text)}</p>`
      }
      <div class="cl-card-actions">
        ${c.el ? `<button class="cl-jump">↗ Jump to comment</button>` : ""}
        <span class="cl-actions-right">
          <button class="cl-reclassify-btn">✏️ Reclassify</button>
        </span>
      </div>
    `;

    // Toxic reveal
    if (isToxic) {
      const revealBtn   = card.querySelector(".cl-reveal");
      const blurredText = card.querySelector(".cl-text--blurred");
      revealBtn?.addEventListener("click", () => {
        blurredText.classList.remove("cl-text--blurred");
        revealBtn.remove();
      });
    }

    // Jump to comment
    card.querySelector(".cl-jump")?.addEventListener("click", () => {
      c.el.scrollIntoView({ behavior: "smooth", block: "center" });
      c.el.style.outline = `2px solid ${cat.color}`;
      c.el.style.outlineOffset = "2px";
      setTimeout(() => { c.el.style.outline = ""; c.el.style.outlineOffset = ""; }, 2200);
    });

    // Reclassify — open to all users, no gate
    card.querySelector(".cl-reclassify-btn")?.addEventListener("click", () => {
      _showReclassifyPanel(card, c, catId, CATEGORIES);
    });

    return card;
  }

  // ─── RECLASSIFY PANEL ─────────────────────────────────────────────────────────

  function _showReclassifyPanel(card, comment, currentCatId, CATEGORIES) {
    const FB = window.CommentLensFeedback;
    card.querySelector(".cl-reclassify-panel")?.remove();

    const panel = document.createElement("div");
    panel.className = "cl-reclassify-panel";

    panel.innerHTML = `
      <div class="cl-rp-header">
        <span class="cl-rp-title">✏️ Move to correct category</span>
        <button class="cl-rp-close">✕</button>
      </div>
      <p class="cl-rp-hint">Your correction is saved locally and teaches CommentLens for future comments. Only you see this change.</p>
      <div class="cl-rp-cats"></div>
      <p class="cl-rp-saved" style="display:none">✅ Saved! CommentLens will remember this.</p>
    `;

    panel.querySelector(".cl-rp-close").addEventListener("click", () => panel.remove());

    const catsEl = panel.querySelector(".cl-rp-cats");
    const catOrder = ["supportive", "critical", "neutral", "toxic", "other"];

    catOrder.forEach(catId => {
      const cat = CATEGORIES[catId];
      const btn = document.createElement("button");
      btn.className = "cl-rp-cat" + (catId === currentCatId ? " cl-rp-cat--current" : "");
      btn.style.setProperty("--cat-color", cat.color);
      btn.innerHTML = `${cat.emoji} <span>${cat.shortLabel}</span>`;
      btn.disabled = catId === currentCatId;
      btn.title = catId === currentCatId ? "Current category" : `Move to ${cat.shortLabel}`;

      btn.addEventListener("click", async () => {
        catsEl.querySelectorAll(".cl-rp-cat").forEach(b => (b.disabled = true));

        if (FB) await FB.saveCorrection(comment.text, currentCatId, catId);

        // Update the card visuals immediately
        const newCat = CATEGORIES[catId];
        const pill   = card.querySelector(".cl-cat-pill");
        if (pill) {
          pill.style.setProperty("--cat-color", newCat.color);
          pill.textContent = `${newCat.emoji} ${newCat.shortLabel}`;
        }
        card.style.setProperty("--cat-color", newCat.color);

        // Add / update corrected badge
        let badge = card.querySelector(".cl-corrected-badge");
        if (!badge) {
          badge = document.createElement("span");
          badge.className = "cl-corrected-badge";
          card.querySelector(".cl-spacer")?.after(badge);
        }
        badge.title   = "You reclassified this";
        badge.textContent = "✓ Reclassified";

        panel.querySelector(".cl-rp-saved").style.display = "block";
        catsEl.style.display = "none";
        setTimeout(() => panel.remove(), 1800);
      });

      catsEl.appendChild(btn);
    });

    card.appendChild(panel);
    panel.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }

  // ─── UTIL ─────────────────────────────────────────────────────────────────────

  function escapeHtml(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

})();
