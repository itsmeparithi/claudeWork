/**
 * CommentLens – YouTube Content Script
 * Scrapes YouTube comments and injects the sentiment overlay.
 */

(function () {
  "use strict";

  const PLATFORM = "youtube";
  let observer = null;
  let debounceTimer = null;
  let lastUrl = location.href;
  let isProcessing = false;

  // ─── SELECTORS ───────────────────────────────────────────────────────────────

  const SELECTORS = {
    commentsSection: "ytd-comments#comments",
    commentThread: "ytd-comment-thread-renderer",
    commentBody: "#content-text",
    authorName: "#author-text span",
    avatar: "#author-thumbnail img",
    commentsContainer: "#contents.ytd-item-section-renderer"
  };

  // ─── SCRAPER ─────────────────────────────────────────────────────────────────

  function scrapeComments() {
    const threads = document.querySelectorAll(SELECTORS.commentThread);
    const comments = [];

    threads.forEach((thread, idx) => {
      const bodyEl = thread.querySelector(SELECTORS.commentBody);
      const authorEl = thread.querySelector(SELECTORS.authorName);
      const avatarEl = thread.querySelector(SELECTORS.avatar);

      if (!bodyEl) return;

      const text = bodyEl.innerText?.trim();
      if (!text || text.length < 2) return;

      comments.push({
        id: idx,
        text,
        authorName: authorEl?.innerText?.trim() || "Anonymous",
        avatarUrl: avatarEl?.src || null,
        el: thread
      });
    });

    return comments;
  }

  // ─── MOUNT ───────────────────────────────────────────────────────────────────

  function tryMount() {
    if (isProcessing) return;

    const commentsSection = document.querySelector(SELECTORS.commentsSection);
    if (!commentsSection) return;

    const container = commentsSection.querySelector(SELECTORS.commentsContainer);
    if (!container) return;

    const threads = commentsSection.querySelectorAll(SELECTORS.commentThread);
    if (threads.length < 1) return;

    isProcessing = true;

    const comments = scrapeComments();
    if (comments.length === 0) {
      isProcessing = false;
      return;
    }

    // Find or create mount point just above the comments list
    let mountPoint = commentsSection.querySelector(".cl-mount-yt");
    if (!mountPoint) {
      mountPoint = document.createElement("div");
      mountPoint.className = "cl-mount-yt";
      commentsSection.prepend(mountPoint);
    }

    window.CommentLensUI.render(mountPoint, comments, { platform: PLATFORM });
    isProcessing = false;
  }

  function debouncedMount(delay = 1800) {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(tryMount, delay);
  }

  // ─── OBSERVE ─────────────────────────────────────────────────────────────────

  function startObserving() {
    if (observer) observer.disconnect();

    observer = new MutationObserver((mutations) => {
      const relevant = mutations.some(m =>
        [...m.addedNodes].some(n =>
          n.nodeType === 1 &&
          (n.matches?.(SELECTORS.commentThread) ||
           n.querySelector?.(SELECTORS.commentThread))
        )
      );
      if (relevant) debouncedMount(800);
    });

    observer.observe(document.body, { childList: true, subtree: true });
  }

  // ─── SPA NAV (YouTube is a SPA) ──────────────────────────────────────────────

  function onNavChange() {
    const currentUrl = location.href;
    if (currentUrl === lastUrl) return;
    lastUrl = currentUrl;

    // Remove existing overlay on page change
    const existing = document.getElementById("commentlens-overlay");
    if (existing) existing.remove();

    const mountPoint = document.querySelector(".cl-mount-yt");
    if (mountPoint) mountPoint.remove();

    isProcessing = false;

    // Only run on video pages
    if (currentUrl.includes("/watch")) {
      debouncedMount(2500);
    }
  }

  // YouTube uses history.pushState for navigation
  const _pushState = history.pushState.bind(history);
  history.pushState = function (...args) {
    _pushState(...args);
    onNavChange();
  };

  window.addEventListener("popstate", onNavChange);

  // ─── INIT ────────────────────────────────────────────────────────────────────

  function init() {
    if (location.href.includes("/watch")) {
      startObserving();
      debouncedMount(3000);
    } else {
      // Still watch for navigation to watch pages
      startObserving();
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

})();
