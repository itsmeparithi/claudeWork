/**
 * CommentLens – Multilingual Sentiment Engine v3
 *
 * New in v3:
 *  · Tamil, Telugu, Malayalam, Kannada — script detection + native lexicons
 *  · Learned weight integration (from feedback corrections)
 *  · Dravidian script Unicode range detection
 *
 * Architecture:
 *  1. TOXICITY  → Perspective API (100+ languages) + regex pre-filter
 *  2. SENTIMENT → Emoji valence + multilingual lexicon + Dravidian scripts
 *                 + learned weights from trusted user corrections
 */

(function () {
  "use strict";

  const PERSPECTIVE_KEY = ""; // ← optional: https://developers.perspectiveapi.com
  const PERSPECTIVE_URL = "https://commentanalyzer.googleapis.com/v1alpha1/comments:analyze";
  const TOXIC_THRESHOLD = 0.80;

  // ─── DRAVIDIAN SCRIPT DETECTION ──────────────────────────────────────────────
  // Unicode block ranges for each script

  const SCRIPT_RANGES = {
    tamil:     [0x0B80, 0x0BFF],
    telugu:    [0x0C00, 0x0C7F],
    kannada:   [0x0C80, 0x0CFF],
    malayalam: [0x0D00, 0x0D7F],
  };

  function detectDravidianScript(text) {
    const counts = { tamil: 0, telugu: 0, kannada: 0, malayalam: 0 };
    for (const ch of text) {
      const cp = ch.codePointAt(0);
      for (const [lang, [lo, hi]] of Object.entries(SCRIPT_RANGES)) {
        if (cp >= lo && cp <= hi) counts[lang]++;
      }
    }
    const dominant = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
    return dominant[1] > 2 ? dominant[0] : null;
  }

  // ─── DRAVIDIAN LEXICONS (native script) ──────────────────────────────────────

  const DRAVIDIAN_POSITIVE = {
    tamil: new Set([
      // Positive — Tamil
      "அருமை","சுண்டை","நல்லது","நல்ல","மிகவும்","சரி","அழகு","அமைதி",
      "மகிழ்ச்சி","புகழ்","வெற்றி","உண்மை","அன்பு","நன்றி","மேலான",
      "சிறந்த","சிறப்பு","அற்புதம்","வியப்பு","மகிழ்வு","பாராட்டு",
      "ஆச்சரியம்","இனிமை","இதயம்","தலைசிறந்த","கலைஞர்","திறமை",
    ]),
    telugu: new Set([
      // Positive — Telugu
      "అద్భుతం","చాలా","మంచిది","సరైంది","అందమైన","ఆనందం","విజయం",
      "ప్రేమ","ధన్యవాదాలు","గొప్ప","అభినందనలు","అద్భుతమైన","చక్కని",
      "శ్రేష్ఠమైన","ఉత్కృష్టమైన","మహా","అద్వితీయ","ప్రతిభావంతుడు",
    ]),
    kannada: new Set([
      // Positive — Kannada
      "ಅದ್ಭುತ","ಚೆನ್ನಾಗಿದೆ","ಒಳ್ಳೆಯದು","ಸುಂದರ","ಆನಂದ","ವಿಜಯ",
      "ಪ್ರೀತಿ","ಧನ್ಯವಾದ","ಮಹಾನ್","ಅಭಿನಂದನೆ","ಅದ್ಭುತವಾದ","ಶ್ರೇಷ್ಠ",
      "ಉತ್ಕೃಷ್ಟ","ಪ್ರತಿಭಾವಂತ","ಸೊಗಸಾದ","ಅದ್ಭುತ","ನಲ್ಲ",
    ]),
    malayalam: new Set([
      // Positive — Malayalam
      "അടിപൊളി","നല്ലത്","അദ്ഭുതം","സുന്ദരം","സന്തോഷം","വിജയം",
      "സ്നേഹം","നന്ദി","മഹാൻ","അഭിനന്ദനം","അദ്ഭുതകരം","ശ്രേഷ്ഠം",
      "ഉത്കൃഷ്ടം","പ്രതിഭാശാലി","മനോഹരം","ഇഷ്ടം","ഭംഗി","കിടിലം",
    ]),
  };

  const DRAVIDIAN_NEGATIVE = {
    tamil: new Set([
      // Negative — Tamil
      "மோசம்","தவறு","பொய்","ஏமாற்று","சலிப்பு","தோல்வி","கெட்ட",
      "வெறுப்பு","வலிக்கிறது","கஷ்டம்","நம்பகமற்ற","அவமானம்",
      "பிழை","குற்றம்","நீதியற்ற","ஊழல்","அயோக்கியன்","வீண்",
    ]),
    telugu: new Set([
      // Negative — Telugu
      "చెడు","తప్పు","అబద్ధం","మోసం","విఫలం","నిరాశ","ద్వేషం",
      "అవమానం","దోషం","అన్యాయం","అవినీతి","నమ్మకద్రోహం","వ్యర్థం",
      "నిరుపయోగం","అన్యాయంగా","అసత్యం","తప్పిదం",
    ]),
    kannada: new Set([
      // Negative — Kannada
      "ಕೆಟ್ಟದು","ತಪ್ಪು","ಸುಳ್ಳು","ಮೋಸ","ವಿಫಲ","ನಿರಾಶೆ","ದ್ವೇಷ",
      "ಅವಮಾನ","ದೋಷ","ಅನ್ಯಾಯ","ಭ್ರಷ್ಟ","ನಿರುಪಯೋಗಿ","ವ್ಯರ್ಥ",
      "ನಂಬಿಕೆ ದ್ರೋಹ","ಅಸತ್ಯ","ಕೆಡುಕು",
    ]),
    malayalam: new Set([
      // Negative — Malayalam
      "മോശം","തെറ്റ്","നുണ","വഞ്ചന","പരാജയം","നിരാശ","വെറുപ്പ്",
      "അപമാനം","കുറ്റം","അന്യായം","അഴിമതി","വ്യർഥം","ഉപകാരശൂന്യം",
      "വിശ്വാസവഞ്ചന","അസത്യം","ദോഷം",
    ]),
  };

  // Romaji/transliterated versions (people often type Dravidian languages in English letters)
  const DRAVIDIAN_ROMAJI_POSITIVE = new Set([
    // Tamil romaji
    "arumai","nalla","nalladu","miga","miku","vanakkam","superb","thani","romba",
    "superaa","kalakkal","semma","poyya","jolly","vazhga","vetri","inimei",
    // Telugu romaji
    "bagunna","chala","manchidi","sarige","ananda","vijayam","prema","dhanyavad",
    "goppa","abhinandan","chakkani","sresta","prathiba",
    // Kannada romaji
    "chennagide","ollayadu","sundara","ananda","vijaya","priti","dhanyavada",
    "mahaan","abhinandane","sreesta","prathiba","sogasaada",
    // Malayalam romaji
    "adipoli","nallath","adipoli","santhosham","vijayam","sneham","nandi",
    "mahan","abhinandanam","manoharam","ishtam","bhangi","kidilam","superb",
  ]);

  const DRAVIDIAN_ROMAJI_NEGATIVE = new Set([
    // Tamil romaji
    "mosam","thappu","poi","ematru","tholvi","vettam","verupppu","kashdam",
    "pizhei","kutram","avamaanam","yosipu",
    // Telugu romaji
    "chedu","tappu","abaddam","mosanam","viphalamu","nirasa","dvesam",
    "avamaanam","dosham","anyayam","avineeti",
    // Kannada romaji
    "keddadu","tappu","sulli","mosa","viphala","nirashae","dvesha",
    "avamana","dosha","anyaya","bhrushta","nirupa",
    // Malayalam romaji
    "mosham","thettu","nuna","vanchana","parajayam","nirasha","veruppu",
    "apamanam","kuttam","anyayam","azhimati","vyartham",
  ]);

  // ─── TOXIC-ONLY REGEX ─────────────────────────────────────────────────────────

  const TOXIC_SLUR_PATTERNS = [
    /\bf+[u*@#]+c+k\s*(you|off|ur|u|him|her|them)\b/i,
    /\bs+[h*@]+[i!1]+t+\s*(head|face|bag|eater)\b/i,
    /\ba+[s$]+[s$]+h+[o0]+l+e\b/i,
    /\bb+[i!1]+t+c+h\b/i,
    /\bc+[u*]+n+t\b/i,
    /\bwh+[o0]+r+e\b/i,
    /\bs+l+[u*]+t\b/i,
    /\bm+[o0]+t+h+e+r+f+[u*]+c+k/i,
    /\bcock\s*suck/i,
    /\bn+[i!1*]+g+[g*]+[aer]+\b/i,
    /\bf+[a@]+g+(g+[o0]+t)?\b/i,
    /\btr+[a@]+n+n+[yi]\b/i,
    /\bsp[i!1]+c\b/i,
    /\bch[i!1]+n+k\b/i,
    /\bkill\s+your\s*self\b/i,
    /\bkys\b/i,
    /\bgo\s+die\b/i,
    /\bi('ll|will)\s+(kill|murder)\s+(you|u)\b/i,
    /\bsuck\s+my\s+(dick|cock|balls)\b/i,
    /\bfuck\s+(you|ur|u|off|him|her|them)\b/i,
  ];

  // ─── EMOJI VALENCE ────────────────────────────────────────────────────────────

  const EMOJI_POSITIVE = new Set([
    "❤️","♥️","🧡","💛","💚","💙","💜","🖤","🤍","🤎","💕","💞","💓","💗","💖","💝","💘",
    "😍","🥰","😘","😊","😁","😄","😃","🤩","🥳","😎","🤗","😇",
    "👍","👏","🙌","🤝","🫶","💪","✊","🙏","🤜","🤛",
    "🔥","✨","⭐","🌟","💯","🏆","🥇","👑","💎","🎉","🎊","🎯",
    "❤","♥","👌","🫡","🫰","🤙","🫂","💐","🌹","🌸","🌺","😂","🤣",
  ]);

  const EMOJI_NEGATIVE = new Set([
    "👎","🖕","😡","🤬","😤","😠","🤢","🤮","💩","🗑️","🚮",
    "😒","🙄","😑","😐","😶","😣","😖","😫","😩",
    "💔","😢","😭","😞","😟","😔","😕",
  ]);

  // ─── MULTILINGUAL LEXICON (all non-Dravidian languages) ──────────────────────

  const POSITIVE_TERMS = new Set([
    // English
    "love","amazing","awesome","excellent","fantastic","wonderful","brilliant",
    "great","superb","incredible","outstanding","perfect","beautiful","best",
    "good","nice","cool","enjoy","enjoyed","thank","thanks","appreciate",
    "helpful","inspiring","agree","absolutely","congrats","congratulations",
    "proud","respect","legend","genius","talented","blessed","happy","glad",
    "pleased","impressed","phenomenal","stellar","spectacular","masterpiece",
    "iconic","underrated","fire","goat","wholesome","heartwarming","delightful",
    "impressive","insightful","useful","informative","accurate","correct","true",
    "refreshing","honest","fair","balanced","clear",
    // Spanish
    "increíble","genial","excelente","fantástico","maravilloso","perfecto",
    "hermoso","hermosa","mejor","bueno","buena","gracias","feliz",
    "impresionante","amor","encanta","bravo","magnífico","estupendo",
    "asombroso","espectacular","sensacional",
    // French
    "incroyable","génial","excellent","fantastique","merveilleux","parfait",
    "beau","belle","meilleur","bon","bonne","merci","heureux","impressionnant",
    "magnifique","formidable","superbe","bravo","félicitations","sympa",
    // German
    "unglaublich","toll","ausgezeichnet","fantastisch","wunderbar","perfekt",
    "schön","beste","gut","danke","glücklich","beeindruckend","großartig",
    "wunderschön","hervorragend","klasse","super","brillant",
    // Portuguese
    "incrível","ótimo","excelente","fantástico","maravilhoso","perfeito",
    "lindo","linda","melhor","bom","boa","obrigado","obrigada","feliz",
    "impressionante","adorei","parabéns","sensacional","espetacular","top",
    // Italian
    "incredibile","ottimo","eccellente","fantastico","meraviglioso","perfetto",
    "bellissimo","bellissima","migliore","buono","buona","grazie","felice",
    "magnifico","stupendo","bravissimo","complimenti","bravo","brava",
    // Japanese (romaji)
    "sugoi","kawaii","arigatou","saikou","umai","yatta","subarashii","ii",
    "tanoshi","yokatta","suki","daisuki","kirei","kakkoii",
    // Korean (romaji)
    "daebak","jinjja","gomawo","jjang","hwaiting","fighting","saranghae",
    "choegoyo","johda",
    // Hindi (romaji)
    "bahut accha","shukriya","dhanyawad","shaandaar","zabardast","wah",
    "kamaal","mast","badhiya","sundar","achha","sahi",
    // Russian (romaji)
    "ochen horosho","otlichno","spasibo","lyubov","krasivo","prekrasno",
    "zamechatelno","zdorovo",
    // Arabic (romaji)
    "mumtaz","shukran","jamil","mashallah","tayeb",
    // Turkish
    "harika","mükemmel","güzel","teşekkür","süper","inanılmaz","bravo",
    "muhteşem","çok iyi",
    // Indonesian/Malay
    "bagus","keren","luar biasa","terima kasih","mantap","hebat","indah",
    "sempurna","terbaik","suka","senang","kagum",
  ]);

  const NEGATIVE_TERMS = new Set([
    // English
    "wrong","incorrect","disagree","false","misleading","lie","lying","lies",
    "bad","terrible","awful","horrible","worst","poor","weak","overrated",
    "disappointing","disappointed","fail","failed","failure","mistake","error",
    "flawed","biased","unfair","unjust","propaganda","clickbait","waste",
    "boring","dull","mediocre","useless","pointless","irrelevant","outdated",
    "inaccurate","exaggerated","nonsense","absurd","ridiculous","unfortunately",
    "sadly","corrupt","incompetent","irresponsible","hypocrite","deceptive",
    "manipulative","dishonest","exploitative","lazy",
    // Spanish
    "malo","mala","terrible","horrible","peor","aburrido","inútil","mentira",
    "decepcionante","fracaso","error","equivocado","basura","lamentable",
    "vergonzoso","ridículo","falso","corrupto","pésimo",
    // French
    "mauvais","mauvaise","terrible","horrible","pire","ennuyeux","inutile",
    "mensonge","décevant","échec","erreur","faux","nul","lamentable","honteux",
    // German
    "schlecht","schrecklich","schlechteste","langweilig","nutzlos","lüge",
    "enttäuschend","versagen","fehler","falsch","müll","furchtbar","peinlich",
    // Portuguese
    "ruim","terrível","horrível","pior","chato","inútil","mentira",
    "decepcionante","fracasso","erro","errado","lixo","ridículo","vergonhoso",
    // Italian
    "cattivo","cattiva","terribile","orribile","peggiore","noioso","inutile",
    "bugiardo","deludente","fallimento","errore","sbagliato","spazzatura",
    // Japanese (romaji)
    "warui","dame","tsumaranai","uso","hidoi","mazui","iya",
    // Korean (romaji)
    "nappeo","geojitmal","silmang","sireo","byeolro",
    // Hindi (romaji)
    "bura","galat","jhooth","bekaar","bakwas","ghatiya","bekar",
    // Russian (romaji)
    "ploho","nepravilno","uzhasno","glupo","razocharo","lozh",
    // Arabic (romaji)
    "sayyi","ghalet","kazib",
    // Turkish
    "kötü","berbat","yanlış","hayal kırıklığı","başarısız","saçma","yalan",
    "zavallı","işe yaramaz","rezalet",
    // Indonesian/Malay
    "buruk","jelek","salah","kecewa","gagal","bohong","sampah","percuma",
    "membosankan","payah",
  ]);

  const NEGATION_TOKENS = new Set([
    "not","no","never","neither","nor","hardly","scarcely","barely",
    "doesn't","don't","didn't","isn't","aren't","wasn't","weren't",
    "won't","wouldn't","can't","cannot","couldn't","shouldn't","n't",
    "nunca","jamás","tampoco","ni","sin",
    "ne","pas","jamais","non","sans","aucun",
    "nicht","kein","nie","niemals","nein","ohne","nichts",
    "não","nunca","jamais","nem","nenhum","sem",
    "non","mai","nessuno","né","senza",
    "nai","naku","dame","iya","chigau",
    "anio","an","mot","eopda",
    "nahi","mat","na","bilkul",
    "net","ne","nikogda","nichego","bez",
    "la","lan","lam","laysa",
    "değil","hiç","hiçbir","olmadan",
    "tidak","bukan","jangan","tanpa","belum",
    // Dravidian romaji negations
    "illai","vendam","ille","alla","onnum","edhuvum",  // Tamil
    "ledu","kaadu","vaddhu","emee","emi","kaadhu",      // Telugu
    "illa","alla","beda","enu","yenu",                  // Kannada
    "alla","illaa","venda","onnum","ethum",             // Malayalam
  ]);

  // ─── CATEGORIES ──────────────────────────────────────────────────────────────

  const CATEGORIES = {
    supportive: {
      id: "supportive", label: "💚 Supportive", shortLabel: "Supportive",
      emoji: "💚", description: "Praise, agreement & encouragement", color: "#22c55e"
    },
    critical: {
      id: "critical", label: "🔴 Critical", shortLabel: "Critical",
      emoji: "🔴", description: "Disagreement, counterpoints & opposition", color: "#ef4444"
    },
    neutral: {
      id: "neutral", label: "⚪ Neutral", shortLabel: "Neutral",
      emoji: "⚪", description: "Observations, questions & general chat", color: "#94a3b8"
    },
    toxic: {
      id: "toxic", label: "🚫 Toxic", shortLabel: "Toxic",
      emoji: "🚫", description: "Vulgar, hateful or threatening language", color: "#f97316"
    },
    other: {
      id: "other", label: "📦 Other", shortLabel: "Other",
      emoji: "📦", description: "Spam, unclassifiable or very short comments", color: "#a855f7"
    }
  };

  // ─── HELPERS ─────────────────────────────────────────────────────────────────

  function emojiScore(text) {
    const emojis = [...(text.match(/\p{Emoji_Presentation}/gu) || [])];
    let pos = 0, neg = 0;
    emojis.forEach(e => {
      if (EMOJI_POSITIVE.has(e)) pos++;
      if (EMOJI_NEGATIVE.has(e)) neg++;
    });
    return { pos, neg };
  }

  function punctuationSignals(text) {
    return {
      exclamations: (text.match(/!/g) || []).length,
      questions:    (text.match(/\?/g) || []).length,
    };
  }

  function tokenizeLower(text) {
    return text
      .toLowerCase()
      .split(/[\s,\.!?;:()\[\]{}"'""''…\-–—\/\\]+/)
      .filter(t => t.length > 1);
  }

  // Score with base lexicon + optional learned weights
  function scoreTokens(tokens, learnedPos, learnedNeg) {
    let pos = 0, neg = 0;
    let negationActive = false;
    let negationCooldown = 0;

    for (const t of tokens) {
      if (NEGATION_TOKENS.has(t)) {
        negationActive = true;
        negationCooldown = 3;
        continue;
      }

      if (negationCooldown > 0) negationCooldown--;
      if (negationCooldown === 0) negationActive = false;

      const learnedPosW = learnedPos[t] || 0;
      const learnedNegW = learnedNeg[t] || 0;

      const isPositive = POSITIVE_TERMS.has(t) || DRAVIDIAN_ROMAJI_POSITIVE.has(t) || learnedPosW > 0;
      const isNegative = NEGATIVE_TERMS.has(t) || DRAVIDIAN_ROMAJI_NEGATIVE.has(t) || learnedNegW > 0;

      // Base weight + any learned boost (capped at 2.0 extra)
      const posWeight = 1.0 + Math.min(learnedPosW, 2.0);
      const negWeight = 1.0 + Math.min(learnedNegW, 2.0);

      if (isPositive) {
        negationActive ? (neg += 1.3 * posWeight) : (pos += posWeight);
      } else if (isNegative) {
        negationActive ? (pos += 0.5 * negWeight) : (neg += negWeight);
      }
    }
    return { pos, neg };
  }

  // Score Dravidian native script tokens
  function scoreDravidian(text, script) {
    let pos = 0, neg = 0;
    const posSet = DRAVIDIAN_POSITIVE[script];
    const negSet = DRAVIDIAN_NEGATIVE[script];
    if (!posSet || !negSet) return { pos, neg };

    // Split on common Dravidian punctuation + whitespace
    const tokens = text.split(/[\s,।॥!?;\-]+/).filter(t => t.length > 0);
    tokens.forEach(t => {
      if (posSet.has(t)) pos += 1.5; // Native script words get higher confidence
      if (negSet.has(t)) neg += 1.5;
    });
    return { pos, neg };
  }

  // ─── TOXIC CHECK ─────────────────────────────────────────────────────────────

  function isRegexToxic(text) {
    return TOXIC_SLUR_PATTERNS.some(p => p.test(text));
  }

  async function perspectiveToxicity(text) {
    if (!PERSPECTIVE_KEY) return null;
    try {
      const res = await fetch(`${PERSPECTIVE_URL}?key=${PERSPECTIVE_KEY}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          comment: { text },
          requestedAttributes: {
            TOXICITY: {}, SEVERE_TOXICITY: {},
            THREAT: {}, SEXUALLY_EXPLICIT: {}, IDENTITY_ATTACK: {}
          },
          languages: []
        })
      });
      if (!res.ok) return null;
      const data = await res.json();
      const a = data.attributeScores;
      const severeSigs = [
        a?.SEVERE_TOXICITY?.summaryScore?.value ?? 0,
        a?.THREAT?.summaryScore?.value ?? 0,
        a?.SEXUALLY_EXPLICIT?.summaryScore?.value ?? 0,
        a?.IDENTITY_ATTACK?.summaryScore?.value ?? 0,
      ];
      const toxicity = a?.TOXICITY?.summaryScore?.value ?? 0;
      return severeSigs.some(s => s >= TOXIC_THRESHOLD) || toxicity >= TOXIC_THRESHOLD;
    } catch {
      return null;
    }
  }

  // ─── CORE SENTIMENT SCORER ───────────────────────────────────────────────────

  function scoreSentiment(trimmed, learnedPos = {}, learnedNeg = {}) {
    // Detect Dravidian script first
    const dravidianScript = detectDravidianScript(trimmed);

    const tokens = tokenizeLower(trimmed);
    const { pos: termPos, neg: termNeg } = scoreTokens(tokens, learnedPos, learnedNeg);
    const { pos: ePos,    neg: eNeg    } = emojiScore(trimmed);
    const { exclamations, questions }    = punctuationSignals(trimmed);

    let totalPos = termPos + (ePos * 2.0) + (exclamations * 0.25);
    let totalNeg = termNeg + (eNeg * 2.0);

    // Add Dravidian native script scores if detected
    if (dravidianScript) {
      const { pos: dPos, neg: dNeg } = scoreDravidian(trimmed, dravidianScript);
      totalPos += dPos;
      totalNeg += dNeg;
    }

    const total = totalPos + totalNeg;

    if (total < 0.8) {
      if (questions > 0)                      return "neutral";
      if (trimmed.split(/\s+/).length < 4)    return "other";
      return "neutral";
    }

    const ratio = totalPos / total;
    if (ratio >= 0.60) return "supportive";
    if (ratio <= 0.40) return "critical";
    return "neutral";
  }

  // ─── PUBLIC API ──────────────────────────────────────────────────────────────

  // Async classify — checks corrections first, then Perspective API, then lexicon
  async function classify(text) {
    if (!text || typeof text !== "string") return "other";
    const trimmed = text.trim();
    if (trimmed.length < 3) return "other";

    // 1. Check if a trusted user has already corrected this exact comment
    if (window.CommentLensFeedback) {
      const correction = await window.CommentLensFeedback.getCorrection(trimmed);
      if (correction) return correction.correct;
    }

    // 2. Fast regex toxic check
    if (isRegexToxic(trimmed)) return "toxic";

    // 3. Perspective API toxic check
    const apiResult = await perspectiveToxicity(trimmed);
    if (apiResult === true) return "toxic";

    // 4. Sentiment with learned weights
    const learned = window.CommentLensFeedback
      ? window.CommentLensFeedback.getLearnedWeightsSync()
      : { positive: {}, negative: {} };

    return scoreSentiment(trimmed, learned.positive, learned.negative);
  }

  // Sync classify — instant, no async ops
  function classifySync(text) {
    if (!text || typeof text !== "string") return "other";
    const trimmed = text.trim();
    if (trimmed.length < 3) return "other";
    if (isRegexToxic(trimmed)) return "toxic";

    const learned = window.CommentLensFeedback
      ? window.CommentLensFeedback.getLearnedWeightsSync()
      : { positive: {}, negative: {} };

    return scoreSentiment(trimmed, learned.positive, learned.negative);
  }

  // ─── EXPORT ──────────────────────────────────────────────────────────────────

  window.CommentLens = {
    classify,
    classifySync,
    CATEGORIES,
    PERSPECTIVE_KEY,
    detectDravidianScript,
    version: "3.0.0"
  };

})();
