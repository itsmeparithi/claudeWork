/**
 * CommentLens – Feedback System v2
 *
 * All corrections are stored in chrome.storage.local — completely sandboxed
 * to the individual user's browser. No server, no sharing, no trust gate needed.
 *
 * Any user can reclassify any comment. Their corrections only affect their
 * own experience and teach their own local model.
 *
 * Storage keys:
 *   cl_corrections      { [textHash]: { correct, from, text, count, ts } }
 *   cl_learned_positive { [word]: weight }
 *   cl_learned_negative { [word]: weight }
 */

(function () {
  "use strict";

  const KEYS = {
    corrections:     "cl_corrections",
    learnedPositive: "cl_learned_positive",
    learnedNegative: "cl_learned_negative",
  };

  const MAX_WORD_WEIGHT = 5.0;

  // ─── HASHING ─────────────────────────────────────────────────────────────────

  async function textHash(str) {
    const buf = await crypto.subtle.digest(
      "SHA-256",
      new TextEncoder().encode(str.trim().toLowerCase().slice(0, 500))
    );
    return Array.from(new Uint8Array(buf))
      .map(b => b.toString(16).padStart(2, "0"))
      .join("")
      .slice(0, 16);
  }

  // ─── STORAGE ─────────────────────────────────────────────────────────────────

  function get(keys) {
    return new Promise(resolve => chrome.storage.local.get(keys, resolve));
  }

  function set(obj) {
    return new Promise(resolve => chrome.storage.local.set(obj, resolve));
  }

  // ─── CORRECTIONS ─────────────────────────────────────────────────────────────

  async function saveCorrection(commentText, fromCategory, toCategory) {
    const hash = await textHash(commentText);
    const stored = await get([KEYS.corrections, KEYS.learnedPositive, KEYS.learnedNegative]);

    const corrections     = stored[KEYS.corrections]     || {};
    const learnedPos      = stored[KEYS.learnedPositive] || {};
    const learnedNeg      = stored[KEYS.learnedNegative] || {};

    // Save correction as a hard override for this comment
    corrections[hash] = {
      correct: toCategory,
      from:    fromCategory,
      text:    commentText.slice(0, 100),
      count:   (corrections[hash]?.count || 0) + 1,
      ts:      Date.now()
    };

    // Teach the local model from the correction
    const words = _extractTokens(commentText);
    words.forEach(word => {
      if (toCategory === "supportive") {
        learnedPos[word] = Math.min((learnedPos[word] || 0) + 0.5, MAX_WORD_WEIGHT);
        learnedNeg[word] = Math.max((learnedNeg[word] || 0) - 0.2, 0);
      } else if (toCategory === "critical") {
        learnedNeg[word] = Math.min((learnedNeg[word] || 0) + 0.5, MAX_WORD_WEIGHT);
        learnedPos[word] = Math.max((learnedPos[word] || 0) - 0.2, 0);
      }
      // neutral / toxic / other: don't adjust word weights
    });

    await set({
      [KEYS.corrections]:     corrections,
      [KEYS.learnedPositive]: learnedPos,
      [KEYS.learnedNegative]: learnedNeg,
    });
  }

  async function getCorrection(commentText) {
    const hash = await textHash(commentText);
    const stored = await get([KEYS.corrections]);
    return (stored[KEYS.corrections] || {})[hash] || null;
  }

  // ─── LEARNED WEIGHTS ─────────────────────────────────────────────────────────

  let _cache = { positive: {}, negative: {} };

  async function refreshLearnedCache() {
    const stored = await get([KEYS.learnedPositive, KEYS.learnedNegative]);
    _cache = {
      positive: stored[KEYS.learnedPositive] || {},
      negative: stored[KEYS.learnedNegative] || {},
    };
  }

  function getLearnedWeightsSync() {
    return _cache;
  }

  // ─── STATS ────────────────────────────────────────────────────────────────────

  async function getStats() {
    const stored = await get([KEYS.corrections, KEYS.learnedPositive, KEYS.learnedNegative]);
    const corrections = stored[KEYS.corrections]     || {};
    const learnedPos  = stored[KEYS.learnedPositive] || {};
    const learnedNeg  = stored[KEYS.learnedNegative] || {};

    return {
      totalCorrections: Object.keys(corrections).length,
      learnedWords:     new Set([...Object.keys(learnedPos), ...Object.keys(learnedNeg)]).size,
      recentCorrections: Object.values(corrections)
        .sort((a, b) => b.ts - a.ts)
        .slice(0, 6)
        .map(c => ({ from: c.from, to: c.correct, snippet: c.text })),
    };
  }

  // ─── HELPERS ─────────────────────────────────────────────────────────────────

  function _extractTokens(text) {
    return text
      .toLowerCase()
      .split(/[\s,\.!?;:()\[\]{}"'""''…\-–—\/\\]+/)
      .filter(t => t.length > 2 && t.length < 25 && /[a-z\u0080-\uFFFF]/.test(t));
  }

  // ─── EXPORT ──────────────────────────────────────────────────────────────────

  window.CommentLensFeedback = {
    saveCorrection,
    getCorrection,
    getLearnedWeights: async () => {
      const s = await get([KEYS.learnedPositive, KEYS.learnedNegative]);
      return { positive: s[KEYS.learnedPositive] || {}, negative: s[KEYS.learnedNegative] || {} };
    },
    getLearnedWeightsSync,
    refreshLearnedCache,
    getStats,
  };

  // Pre-warm cache on load
  refreshLearnedCache().catch(() => {});

})();
